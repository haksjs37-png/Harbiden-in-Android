JARVIS Android - kurulum
1) Android Studio (Koala veya yenisi) ile bu klasörü aç, "Sync" bekle.
2) Telefonu USB hata ayıklama ile bağla, Run (yeşil üçgen) ile yükle.
   APK için: Build > Build Bundle(s) / APK(s) > Build APK(s)
3) İlk açılışta mikrofon izni ver. Ses tanıma için telefonda Google uygulaması gerekir.

Komut örnekleri: "saat kaç", "bugün günlerden ne", "fener aç/kapat", "pil durumu",
"ses artır/azalt", "alarm kur 7 30", "10 dakika zamanlayıcı", "WhatsApp aç",
"ara 0555 123 45 67", "ara hava durumu". Diğer her şey: Google araması
veya (anahtar girdiysen) yapay zekâ cevabı.

BİLGİSAYARA ANDROID STUDIO KURMADAN APK ALMA (GitHub ile):
1) github.com'da ücretsiz hesap aç, yeni (boş) bir depo oluştur.
2) Bu klasörün içindekileri (.github klasörü dahil) depoya yükle.
3) Depoda Actions sekmesi > "APK olustur" çalışır (2-4 dk). Bitince
   işin sayfasındaki Artifacts > JARVIS-apk'yi indir, zip'in içinden app-debug.apk çıkar.
4) APK'yı telefona at, aç, "bilinmeyen kaynaklardan yüklemeye izin ver" de.
