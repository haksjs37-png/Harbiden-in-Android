package com.jarvis.mobile

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CommandHandler(private val activity: Activity) {

    private val tr = Locale("tr", "TR")
    private val prefs = activity.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val history = JSONArray()

    fun apiKey(): String = prefs.getString("api_key", "") ?: ""
    fun saveApiKey(key: String) = prefs.edit().putString("api_key", key).apply()

    /** Cevap her zaman ana thread'de [done] ile döner. */
    fun process(raw: String, done: (String) -> Unit) {
        val t = raw.lowercase(tr).trim()
        val local = try { handleLocal(t) } catch (e: Exception) { "Bu komutu çalıştıramadım." }
        when {
            local != null -> done(local)
            apiKey().isNotBlank() -> askClaude(raw, apiKey(), done)
            else -> {
                webSearch(raw)
                done("Bunu internette arıyorum.")
            }
        }
    }

    private fun handleLocal(t: String): String? {
        return when {
            t.contains("merhaba") || t.startsWith("selam") ->
                "Merhaba efendim, size nasıl yardımcı olabilirim?"
            t.contains("teşekkür") || t.contains("sağ ol") -> "Rica ederim efendim."
            t.contains("saat kaç") || t == "saat" ->
                "Saat " + SimpleDateFormat("HH:mm", tr).format(Date())
            t.contains("tarih") || t.contains("günlerden") || t.contains("bugün ayın") ->
                SimpleDateFormat("d MMMM yyyy, EEEE", tr).format(Date())
            t.contains("wifi") || t.contains("wi-fi") || t.contains("kablosuz") -> {
                activity.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                "Wi-Fi ayarları açılıyor."
            }
            t.contains("bluetooth") -> {
                activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                "Bluetooth ayarları açılıyor."
            }
            t.contains("yol tarifi") -> navigate(t.substringAfter("yol tarifi").trim())
            t.endsWith(" çal") || t.startsWith("çal ") -> play(t.removeSuffix(" çal").removePrefix("çal ").trim())
            !t.startsWith("ara ") && MATH.containsMatchIn(t) -> calc(t)
            t.contains("şaka") -> JOKES.random()
            t.contains("zar at") -> "Zar ${(1..6).random()} geldi."
            t.contains("yazı tura") -> if ((0..1).random() == 0) "Yazı geldi." else "Tura geldi."
            t.contains("sen kimsin") || t.contains("kendini tanıt") ->
                "Ben JARVIS, cebinizdeki sesli asistanınızım efendim."
            t.contains("fener") -> torch(!t.contains("kapat") && !t.contains("söndür"))
            t.contains("pil") || t.contains("şarj") -> battery()
            t.contains("ses") && listOf("art", "yükselt", "yüksel", "aç").any { t.contains(it) } ->
                volume(true)
            t.contains("ses") && listOf("azalt", "kıs", "düşür").any { t.contains(it) } ->
                volume(false)
            t.contains("alarm") -> alarm(t)
            t.contains("zamanlayıcı") || t.contains("sayaç") -> timer(t)
            t.startsWith("ara ") && t.drop(4).count { it.isDigit() } >= 3 -> dial(t)
            t.startsWith("ara ") || t.startsWith("araştır ") || t.startsWith("google ") -> {
                webSearch(t.substringAfter(' '))
                "Arıyorum."
            }
            t.endsWith(" aç") || t.endsWith(" başlat") || t.startsWith("aç ") -> openApp(t)
            else -> null
        }
    }

    // ---- Komutlar ----

    private fun torch(on: Boolean): String {
        val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Bu cihazda flaş bulunamadı."
        cm.setTorchMode(id, on)
        return if (on) "Fener açıldı." else "Fener kapatıldı."
    }

    private fun battery(): String {
        val bm = activity.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Pil yüzde $pct seviyesinde."
    }

    private fun volume(up: Boolean): String {
        val am = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
        return if (up) "Ses artırıldı." else "Ses azaltıldı."
    }

    private fun numbers(t: String) = Regex("\\d+").findAll(t).map { it.value.toInt() }.toList()

    private fun alarm(t: String): String {
        val n = numbers(t)
        val h = n.getOrNull(0) ?: return "Alarm için saat söyleyin, örneğin: alarm kur 7 30."
        val m = n.getOrNull(1) ?: 0
        if (h !in 0..23 || m !in 0..59) return "Bu saat geçerli değil."
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        activity.startActivity(i)
        return "Alarm %02d:%02d için kuruldu.".format(h, m)
    }

    private fun timer(t: String): String {
        val n = numbers(t).firstOrNull() ?: return "Kaç dakika olacak?"
        val secs = when {
            t.contains("saat") -> n * 3600
            t.contains("saniye") -> n
            else -> n * 60
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, secs)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        activity.startActivity(i)
        return "Zamanlayıcı kuruldu."
    }

    private fun dial(t: String): String {
        val digits = t.filter { it.isDigit() }
        activity.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
        return "Numara çevirici açılıyor."
    }

    private fun webSearch(q: String) {
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun openApp(t: String): String {
        val name = t.removePrefix("aç ").removeSuffix(" aç").removeSuffix(" başlat")
            .substringBefore("'").trim()
        if (name.length < 3) return "Hangi uygulamayı açayım?"
        val pm = activity.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map {
            it.loadLabel(pm).toString().lowercase(tr) to it.activityInfo.packageName
        }
        val match = apps.firstOrNull { it.first == name }
            ?: apps.firstOrNull { it.first.contains(name) || name.contains(it.first) }
            ?: return "$name uygulamasını bulamadım."
        val intent = pm.getLaunchIntentForPackage(match.second)
            ?: return "${match.first} açılamadı."
        activity.startActivity(intent)
        return "${match.first} açılıyor."
    }


    private fun navigate(place: String): String {
        if (place.isBlank()) return "Nereye gitmek istiyorsunuz?"
        val uri = Uri.parse("google.navigation:q=" + URLEncoder.encode(place, "UTF-8"))
        return try {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
            "$place için yol tarifi açılıyor."
        } catch (e: Exception) {
            webSearch("$place yol tarifi")
            "Haritalar bulunamadı, internette arıyorum."
        }
    }

    private fun play(query: String): String {
        if (query.isBlank() || query == "müzik") {
            webSearch("müzik")
            return "Müzik açılıyor."
        }
        val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "$query YouTube'da açılıyor."
    }

    private fun calc(t: String): String {
        val m = MATH.find(t) ?: return "İşlemi anlayamadım."
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val r = when (m.groupValues[2]) {
            "artı", "+" -> a + b
            "eksi" -> a - b
            "çarpı", "*" -> a * b
            "bölü" -> if (b == 0.0) return "Sıfıra bölemem efendim." else a / b
            else -> return "İşlemi anlayamadım."
        }
        val txt = if (r % 1.0 == 0.0) r.toLong().toString() else "%.2f".format(tr, r)
        return "Sonuç $txt"
    }

    // ---- Yapay zekâ (isteğe bağlı) ----

    private fun askClaude(question: String, key: String, done: (String) -> Unit) {
        history.put(JSONObject().put("role", "user").put("content", question))
        Thread {
            val reply = try {
                val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.doOutput = true
                conn.setRequestProperty("content-type", "application/json")
                conn.setRequestProperty("x-api-key", key)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                val body = JSONObject()
                    .put("model", MODEL)
                    .put("max_tokens", 300)
                    .put("system", SYSTEM)
                    .put("messages", history)
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val ok = conn.responseCode in 200..299
                val txt = (if (ok) conn.inputStream else conn.errorStream)
                    .bufferedReader().use { it.readText() }
                if (ok) {
                    val ans = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
                    history.put(JSONObject().put("role", "assistant").put("content", ans))
                    trimHistory()
                    ans
                } else {
                    dropLast()
                    "API hatası ${conn.responseCode}. Anahtarı kontrol edin."
                }
            } catch (e: Exception) {
                dropLast()
                "İnternete bağlanamadım."
            }
            Handler(Looper.getMainLooper()).post { done(reply) }
        }.start()
    }

    private fun dropLast() { if (history.length() > 0) history.remove(history.length() - 1) }

    private fun trimHistory() {
        while (history.length() > 10) { history.remove(0) }
    }

    companion object {
        val MATH = Regex("(\\d+)\\s*(artı|eksi|çarpı|bölü|\\+|\\*)\\s*(\\d+)")
        val JOKES = listOf(
            "Yazılımcıya neden gözlük takarsın demişler, çünkü C Sharp göremiyorum demiş.",
            "Bilgisayar doktora gitmiş, çok virüs var demiş. Doktor da önce bir önbelleğini temizle demiş.",
            "Neden bilgisayar soğuk almaz? Çünkü hep Windows'u açıktır, ama yine de bazen donar."
        )
        const val MODEL = "claude-haiku-5-5"
        const val SYSTEM = "Sen JARVIS adlı sesli bir asistansın. Kullanıcıya her zaman Türkçe, " +
            "kısa (en fazla 2-3 cümle), sade ve düz metin olarak cevap ver. Madde işareti, " +
            "emoji ve markdown kullanma, çünkü cevap sesli okunacak."
    }
}
