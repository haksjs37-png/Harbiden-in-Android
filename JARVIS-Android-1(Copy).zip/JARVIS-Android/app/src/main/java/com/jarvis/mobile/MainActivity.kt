package com.jarvis.mobile

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var micBtn: Button
    private lateinit var continuous: Switch
    private lateinit var commands: CommandHandler

    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logView = findViewById(R.id.log)
        statusView = findViewById(R.id.status)
        scroll = findViewById(R.id.scroll)
        micBtn = findViewById(R.id.mic)
        continuous = findViewById(R.id.continuous)
        commands = CommandHandler(this)
        tts = TextToSpeech(this, this)

        micBtn.setOnClickListener {
            if (listening) stopListening() else startListening()
        }
        findViewById<Button>(R.id.settings).setOnClickListener { askApiKey() }

        log("JARVIS: Merhaba efendim. Mikrofona dokunup konuşabilirsiniz.\n" +
            "Örnek: \"saat kaç\", \"YouTube aç\", \"fenerı aç\", \"alarm kur 7 30\", \"pil durumu\"")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("tr", "TR")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) { afterSpeech() }
                override fun onDone(utteranceId: String?) { afterSpeech() }
            })
            ttsReady = true
        }
    }

    private fun afterSpeech() {
        ui.post { if (continuous.isChecked && !listening) startListening() }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Bu telefonda ses tanıma servisi yok (Google uygulaması gerekli)")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(listener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        listening = true
        micBtn.text = "⏹  Durdur"
        setStatus("Dinliyorum...")
        recognizer?.startListening(intent)
    }

    private fun stopListening() {
        listening = false
        recognizer?.cancel()
        micBtn.text = "🎤  Konuş"
        setStatus("Hazır")
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            listening = false
            micBtn.text = "🎤  Konuş"
            val quiet = error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            if (quiet && continuous.isChecked) {
                ui.postDelayed({ if (!listening) startListening() }, 400)
            } else {
                setStatus(if (quiet) "Sizi duyamadım" else "Ses tanıma hatası ($error)")
            }
        }

        override fun onResults(results: Bundle?) {
            listening = false
            micBtn.text = "🎤  Konuş"
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text.isNullOrBlank()) {
                if (continuous.isChecked) startListening()
                return
            }
            log("Siz: $text")
            setStatus("Düşünüyorum...")
            commands.process(text) { reply -> say(reply) }
        }
    }

    private fun say(reply: String) {
        log("JARVIS: $reply")
        setStatus("Hazır")
        if (ttsReady) {
            tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        } else {
            afterSpeech()
        }
    }

    private fun askApiKey() {
        val input = EditText(this).apply {
            hint = "sk-ant-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(commands.apiKey())
        }
        AlertDialog.Builder(this)
            .setTitle("Claude API anahtarı")
            .setMessage("Girersen komut olmayan sorulara yapay zekâ cevap verir. Boş bırakırsan bilinmeyen sorular Google'da aranır.")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ -> commands.saveApiKey(input.text.toString().trim()) }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun log(line: String) {
        logView.append(line + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setStatus(s: String) { statusView.text = s }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            setStatus("Mikrofon izni gerekli")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
